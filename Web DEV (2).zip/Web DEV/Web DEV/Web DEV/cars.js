window.onload = function() {
    alert("Welcome to HaZzz Motor Cars! Explore our amazing car collection.");
};

document.addEventListener("DOMContentLoaded", function() {
    const bookButtons = document.querySelectorAll(".book-button");

    bookButtons.forEach(button => {
        button.addEventListener("click", function(event) {
            const confirmBooking = confirm("Are you sure you want to book this car?");
            if (confirmBooking) {
                // Redirect to a booking form or show a modal
                window.location.href = "book-car.html"; // Replace with the actual path of your booking form
            } else {
                event.preventDefault(); 
            }
        });
    });
});
